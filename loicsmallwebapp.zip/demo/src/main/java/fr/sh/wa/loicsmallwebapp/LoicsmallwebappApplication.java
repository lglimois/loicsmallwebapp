package fr.sh.wa.loicsmallwebapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoicsmallwebappApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoicsmallwebappApplication.class, args);
	}
}
